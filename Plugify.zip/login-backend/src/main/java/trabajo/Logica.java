package trabajo;

import static spark.Spark.*;
import java.util.*;

public class Logica {

    static class Usuario {
        String email;
        String password;

        Usuario(String e, String p) {
            this.email = e;
            this.password = p;
        }
    }

    public static void main(String[] args) {
        port(8080); // puerto del servidor
        List<Usuario> usuarios = new ArrayList<>();

        // Permitir peticiones desde cualquier origen (CORS)
        before((req, res) -> res.header("Access-Control-Allow-Origin", "*"));

        // --- Ruta de prueba ---
        get("/", (req, res) -> {
            return "Servidor Java con Spark funcionando ";
        });

        // --- Registro de usuario ---
        post("/register", (req, res) -> {
            String email = req.queryParams("email");
            String password = req.queryParams("password");

            usuarios.add(new Usuario(email, password));

            // Mostrar en terminal
            System.out.println(" Usuario registrado: " + email);
            System.out.println("Total de usuarios: " + usuarios.size());

            res.type("application/json");
            return "{\"status\":\"ok\",\"message\":\"Usuario registrado con éxito\"}";
        });

        // --- Login ---
        post("/login", (req, res) -> {
            String email = req.queryParams("email");
            String password = req.queryParams("password");

            boolean existe = usuarios.stream()
                    .anyMatch(u -> u.email.equals(email) && u.password.equals(password));

            // Mostrar en terminal
            if (existe)
                System.out.println(" Login correcto de: " + email);
            else
                System.out.println(" Intento de login fallido: " + email);

            res.type("application/json");
            return existe
                    ? "{\"status\":\"ok\",\"message\":\"Login correcto\"}"
                    : "{\"status\":\"error\",\"message\":\"Credenciales inválidas\"}";
        });

        // --- Ver todos los usuarios registrados ---
        get("/usuarios", (req, res) -> {
            res.type("application/json");

            if (usuarios.isEmpty()) {
                System.out.println(" No hay usuarios registrados.");
                return "{\"usuarios\":[]}";
            }

            StringBuilder json = new StringBuilder();
            json.append("{\"usuarios\":[");
            for (int i = 0; i < usuarios.size(); i++) {
                Usuario u = usuarios.get(i);
                json.append("{\"email\":\"").append(u.email).append("\"}");
                if (i < usuarios.size() - 1) json.append(",");
            }
            json.append("]}");

            System.out.println(" Usuarios registrados: " + usuarios.size());
            return json.toString();
        });
    }
}
